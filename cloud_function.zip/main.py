"""
Main Cloud Function entry point for Sage voice analysis.

This module provides the cloud function handler that processes audio files
uploaded to Firebase Storage and extracts voice analysis features.

Reference: DATA_STANDARDS.md §3.2.1
"""

import functions_framework
import logging
from typing import Optional
from services.audio_processing_service import AudioProcessingService
from utilities.structured_logging import get_audio_processing_logger
from utilities.tool_versions import ToolVersions
from utilities.constants import WAV_EXTENSION, SAGE_AUDIO_FILES_PREFIX

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = get_audio_processing_logger()

# Initialize audio processing service with configurable analysis version
audio_service = AudioProcessingService(analysis_version="1.0")


@functions_framework.cloud_event
def process_audio_file(cloud_event) -> None:
    """
    Main Cloud Function entry point for voice analysis processing.
    
    Args:
        cloud_event: Cloud event containing file upload information
        
    Returns:
        None
        
    Raises:
        Exception: If processing fails
    """
    # Get file info from the cloud event
    event_data = cloud_event.data
    file_name = event_data.get('name', '')
    bucket_name = event_data.get('bucket', '')
    
    # Validate file type
    if not file_name.endswith(WAV_EXTENSION):
        logger.info(f"Skipping non-wav file: {file_name}")
        return
    
    if not file_name.startswith(SAGE_AUDIO_FILES_PREFIX):
        logger.warning(f"Unexpected file path structure: {file_name}")
        return
    
    try:
        # Log processing start
        logger.log_audio_processing_start(file_name, bucket_name)
        
        # Process audio file using the service
        doc_id = audio_service.process_audio_file(bucket_name, file_name)
        
        if doc_id:
            # Extract recording ID for logging
            file_info = audio_service.parse_file_path(file_name)
            recording_id = file_info['recording_id']
            
            # Log successful processing
            logger.log_audio_processing_success(file_name, recording_id, doc_id)
        else:
            logger.warning(f"Audio processing returned no document ID for {file_name}")
            
    except Exception as e:
        # Log processing error
        logger.log_audio_processing_error(file_name, str(e))
        raise 